#include "head.h"           // 包含所有头文件
#define DELAY (3200000)     // 延时参数

// 陀螺仪校准变量
int32_t gz_sum = 0;   // GZ轴数据累加和
int16_t gz_avg = 0;   // GZ轴零点校准值
	
// 主函数，程序入口
int main(void)
{
	// 1. 硬件初始化
	SYSCFG_DL_init();   // 系统配置初始化（时钟、引脚等）
	oled_init();        // OLED显示屏初始化
	MPU6050_Init();     // 陀螺仪+加速度计初始化
    delay_ms(300);      // 等待传感器稳定
	
	// 2. 陀螺仪零点校准：采集100次数据求平均值
	for(uint16_t i = 0; i < 100; i++)
    {
        MPU6050_GetData(&AX, &AY, &AZ, &GX, &GY, &GZ);  // 读取六轴数据
        gz_sum += GZ;                                    // 累加GZ轴数据
        delay_us(8);                                     // 小延时
    }
	gz_avg = (int16_t)(gz_sum / 100);  // 计算平均值作为零点
	
	// 3. 开启定时器中断
	NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);   // 控制定时器中断
    NVIC_EnableIRQ(Motor_INST_INT_IRQN);     // 电机PWM定时器中断
	DL_TimerG_startCounter(Motor_INST);      // 启动电机PWM定时器
	DL_TimerA_startCounter(TIMER_0_INST);    // 启动控制定时器（5ms触发一次）
	
	// 模式控制变量
	int test1=0;        // 当前模式（0=待机,1=模式1,2=模式2,3=模式3,4=模式4,5=灰度调试）
	int test2=0;        // 备用变量
	int test3=0;        // 备用变量
	int lock=0;         // 按键锁定标志（防止误触）
	int clear_oled=0;   // OLED清屏标志

    
	// 主循环，一直运行
	while(1)
	{
    	// 检测按键状态
    	check_buttons();	
		
		// KEY1切换模式（0~5循环）
		if(KeyNum == 1 && lock == 0)
		{
			test1++;
			if(test1 > 5)  // 超过5种模式就回到0
			{
				test1 = 0;
				clear_oled = 0;
			}
		}
		
		// ========== 模式0：待机模式 ==========
		if(test1 == 0)
		{
			if(clear_oled == 0)
			{
				for(int i = 0; i < 8; i++)
					LCD_clear_L(0, i);  // 清空OLED屏幕
				clear_oled = 1;
			}
			display_6_8_string(1, 1, "Press KEY1 TO START");  // 显示提示信息
		}
		
		// ========== 模式1：A点到B点直走（任务1）==========
		if(test1 == 1)
		{
			if(lock == 0)
			{
				display_6_8_string(1, 1, "MODE_1               ");   // 显示模式名称
				display_6_8_string(1, 2, "Now_Angle    :       ");   // 显示当前角度
				display_6_8_number(90, 2, Actual_Yaw);
				display_6_8_string(1, 7, "KEY3 TO START !!! ");     // 提示按KEY3开始
			}
		
			// 按KEY3启动模式1
			if(KeyNum == 3)
			{
				mode0_start = 1;
			}
		}
// ========== 模式2：A-B-C-D-A 一圈（任务2）==========
	if(test1 == 2)
	{
		if(clear_oled == 1)
		{
			for(int i = 0; i < 8; i++)
				LCD_clear_L(0, i);  // 清屏
			clear_oled = 0;
		}
		display_6_8_string(1, 1, "MODE_2             ");      // 显示模式名称
		display_6_8_string(1, 2, "NOW_Angle   :        ");    // 显示当前角度
		display_6_8_number(80, 2, Actual_Yaw);
		
		if(lock == 0){
			display_6_8_string(1, 7, "KEY3 TO Enter        ");
			display_6_8_string(1, 3, "                     ");
			display_6_8_string(1, 4, "                     ");
		}

		// 按KEY3进入角度调整模式
		if(KeyNum == 3 && lock == 0)
		{
			lock = 1;		  
			display_6_8_string(1, 3, "KEY1 TO Left");    // KEY1增加角度补偿
			display_6_8_string(1, 4, "KEY2 TO Right");   // KEY2减少角度补偿
			KeyNum = 0;
		}

		// KEY1增加角度补偿值
		if(KeyNum == 1 && lock == 1)
		{
			mode1_angle++;
			display_6_8_string(1, 5, "Angle_adjust");
			display_6_8_number(80, 5, mode1_angle);
			KeyNum = 0;
		} 
		
		// KEY2减少角度补偿值
		if(KeyNum == 2 && lock == 1)
		{
			mode1_angle--;
			display_6_8_string(1, 5, "Angle_adjust");
			display_6_8_number(80, 5, mode1_angle);
			KeyNum = 0;		
		} 
		
		// 按KEY3确认并启动模式2
		if(KeyNum == 3 && lock == 1)
		{ 
			mode1_start = 1;
		}	   
	}
	
	// ========== 模式3：A-C-B-D-A 一圈（任务3）==========
	if(test1 == 3)
	{
		basespeed = 17;  // 设置基础速度
		if(clear_oled == 1)
		{
			for(int i = 0; i < 8; i++)
				LCD_clear_L(0, i);
			clear_oled = 0;
		}
		display_6_8_string(1, 1, "MODE_3_             ");
		display_6_8_string(1, 2, "NOW_Angle   :        ");	
		display_6_8_number(80, 2, Actual_Yaw);
		
		if(lock == 0){
			display_6_8_string(1, 7, "KEY3 TO Enter        ");
			display_6_8_string(1, 3, "                     ");
			display_6_8_string(1, 4, "                     ");
		}

		if(KeyNum == 3 && lock == 0)
		{
			lock = 1;		  
			display_6_8_string(1, 3, "KEY1 TO Left");
			display_6_8_string(1, 4, "KEY2 TO Right");
			KeyNum = 0;
		}

		if(KeyNum == 1 && lock == 1)
		{
			mode1_angle++;
			display_6_8_string(1, 5, "Angle_adjust");
			display_6_8_number(80, 5, mode1_angle);
			KeyNum = 0;
		} 
		if(KeyNum == 2 && lock == 1)
		{
			mode1_angle--;
			display_6_8_string(1, 5, "Angle_adjust");
			display_6_8_number(80, 5, mode1_angle);
			KeyNum = 0;		
		} 
		if(KeyNum == 3 && lock == 1)
		{ 
			mode2_start = 1;
			mode4_times = 1;  // 跑1圈
		}	   
	}	
	
	// ========== 模式4：A-C-B-D-A 四圈（任务4）==========
	if(test1 == 4)
	{
		basespeed = 15;  // 设置较慢的基础速度
		if(clear_oled == 1)
		{
			for(int i = 0; i < 8; i++)
				LCD_clear_L(0, i);
			clear_oled = 0;
		}
		display_6_8_string(1, 1, "MODE_4_             ");
		display_6_8_string(1, 2, "NOW_Angle   :        ");	
		display_6_8_number(80, 2, Actual_Yaw);
		
		if(lock == 0){
			display_6_8_string(1, 7, "KEY3 TO Enter        ");
			display_6_8_string(1, 3, "                     ");
			display_6_8_string(1, 4, "                     ");
		}

		if(KeyNum == 3 && lock == 0)
		{
			lock = 1;		  
			display_6_8_string(1, 3, "KEY1 TO Left");
			display_6_8_string(1, 4, "KEY2 TO Right");
			KeyNum = 0;
		}

		if(KeyNum == 1 && lock == 1)
		{
			mode1_angle++;
			display_6_8_string(1, 5, "Angle_adjust");
			display_6_8_number(80, 5, mode1_angle);
			KeyNum = 0;
		} 
		if(KeyNum == 2 && lock == 1)
		{
			mode1_angle--;
			display_6_8_string(1, 5, "Angle_adjust");
			display_6_8_number(80, 5, mode1_angle);
			KeyNum = 0;		
		} 
		if(KeyNum == 3 && lock == 1)
		{ 
			mode2_start = 1;
			mode4_times = 4;  // 跑4圈
		}	   
	}
	
	// ========== 模式5：灰度传感器调试模式 ==========
	if(test1 == 5)
	{
		if(clear_oled == 0)
		{
			for(int i = 0; i < 8; i++)
				LCD_clear_L(0, i);
			clear_oled = 1;
		}
			
		HUIDU();  // 读取灰度传感器数据

		// 显示8个传感器的值（0=检测到黑线, 1=检测到白色）
		display_6_8_number(50, 0, sensorPins[0]);
		display_6_8_number(50, 1, sensorPins[1]);
		display_6_8_number(50, 2, sensorPins[2]);
		display_6_8_number(50, 3, sensorPins[3]);
		display_6_8_number(50, 4, sensorPins[4]);
		display_6_8_number(50, 5, sensorPins[5]);
		display_6_8_number(50, 6, sensorPins[6]);
		display_6_8_number(50, 7, sensorPins[7]);
	}
	}
}

        









