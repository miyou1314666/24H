//#ifndef __IMU_H
//#define __IMU_H

//#include "ti_msp_dl_config.h"
//#include "IMU.h"
//#include "myi2C.h"
//#include "MPU6050.h"


//typedef struct{ float AX;
//         	    float AY;
//	            float AZ;
//	            float GX;
//	            float GY;
//	            float GZ;
//                       }param_imu;
//	

//#endif