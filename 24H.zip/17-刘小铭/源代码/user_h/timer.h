#ifndef TIMER_H
#define TIMER_H

void TIMER_0_INST_IRQHandler(void);
extern volatile int Count,Count1,Count2;

#endif