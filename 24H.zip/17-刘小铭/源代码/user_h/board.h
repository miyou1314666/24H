
#ifndef	__BOARD_H__
#define __BOARD_H__

void buzzer_light_clear();
void buzzer_light_setup();
void buzzer_Init();
void buzzer_light_up_and_down();
extern int Timercount;

#endif
