#ifndef MODE_H
#define MODE_H
#include "head.h"


void mode1(void);
void mode2(void);
void mode0(void);
void mode4(void);
extern int basespeed,mode1_start,mode1_times,mode2_start,mode0_start,mode1_angle;

#endif