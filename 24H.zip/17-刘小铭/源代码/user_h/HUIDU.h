#ifndef HUIDU_H
#define HUIDU_H

#include "head.h"

extern volatile int sensorPins[];

void HUIDU(void);
float white(void);

#endif