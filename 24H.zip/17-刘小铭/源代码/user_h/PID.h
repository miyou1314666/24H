#ifndef PID_H
#define PID_H


void HUIDUdouble();
void HUIDUleft();
void HUIDUright();
void Motor();
extern volatile float error1,derivative1,lastError,correction;
extern volatile int Left_Speed,Right_Speed,Target_HUIDU;
extern int HUIDU_test,HUIDU_test3,HUIDU_test1,mode4_times;
#endif