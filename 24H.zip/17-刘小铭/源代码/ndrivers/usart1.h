#ifndef _USART1_H  
#define _USART1_H
#include "head.h"

void usart1_Init(void);
void uart1_send_char(char ch);
void uart1_send_string(char* str);
void UART_1_INST_IRQHandler(void);

extern volatile int32_t uart_data1;
#endif
