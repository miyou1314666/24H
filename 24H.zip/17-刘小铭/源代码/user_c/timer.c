#include "head.h"

volatile int Count1;  // 定时器计数

// 定时器中断处理函数（每5ms触发一次）
void TIMER_0_INST_IRQHandler(void)
{
	switch (DL_TimerG_getPendingInterrupt(TIMER_0_INST)) {
		case DL_TIMER_IIDX_ZERO:  // 定时器溢出中断
			
			Count1++;                      // 计数器加1
			Actual_Yaw_cal();              // 更新角度（MPU6050计算）
			Motor();                       // 更新电机速度
			
			// 根据启动标志执行对应模式
			if(mode0_start == 1) mode0();  // 模式0：A到B直走
			if(mode1_start == 1) mode1();  // 模式1：A-B-C-D-A一圈
			if(mode2_start == 1) mode2();  // 模式2：A-C-B-D-A循环
   
			break;
			
		default:
			break;
	}
}