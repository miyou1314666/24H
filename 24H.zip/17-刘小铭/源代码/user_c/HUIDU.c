#include "head.h"

// 灰度传感器数组（共8个，实际使用中间6个：1~6）
// 值为0表示检测到黑线，值为1表示检测到白色
volatile int sensorPins[] = {0, 1, 2, 3, 4, 5, 6, 7};

// 读取所有灰度传感器的值
void HUIDU(void)
{
	// 传感器1
	if(DL_GPIO_readPins(HUIDU_PIN_5_PORT, HUIDU_PIN_5_PIN)) { sensorPins[1] = 1;}
	else { sensorPins[1] = 0;}
	
	// 传感器2
	if(DL_GPIO_readPins(HUIDU_PIN_6_PORT, HUIDU_PIN_6_PIN)) { sensorPins[2] = 1;}
	else { sensorPins[2] = 0;}
	
	// 传感器3
	if(DL_GPIO_readPins(HUIDU_PIN_7_PORT, HUIDU_PIN_7_PIN)) { sensorPins[3] = 1;}
	else { sensorPins[3] = 0;}
	
	// 传感器4
	if(DL_GPIO_readPins(HUIDU_PIN_8_PORT, HUIDU_PIN_8_PIN)) { sensorPins[4] = 1;}
	else { sensorPins[4] = 0;}
	
	// 传感器5
	if(DL_GPIO_readPins(HUIDU_PIN_9_PORT, HUIDU_PIN_9_PIN)) { sensorPins[5] = 1;}
	else { sensorPins[5] = 0;}
	
	// 传感器6
	if(DL_GPIO_readPins(HUIDU_PIN_10_PORT, HUIDU_PIN_10_PIN)) { sensorPins[6] = 1;}
	else { sensorPins[6] = 0;}
}

// 判断是否所有传感器都检测到白色（即离开了黑线）
// 返回1表示全部是白色，返回0表示至少有一个传感器在黑线上
float white(void)
{
	uint8_t all_white = 1;  // 默认全白
	
	// 检查传感器1~6
	for(int i = 1; i < 7; i++) {
		if(sensorPins[i] == 0) {  // 有一个检测到黑线
			all_white = 0;
			break;
		}
	}
	return all_white;
}