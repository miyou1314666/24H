#include "head.h"
int KeyNum=0;

void check_buttons() {
	
	 KeyNum =0;
    if (!DL_GPIO_readPins(KEY3_PORT, KEY3_PIN)) {
        delay_ms(10);  // ��ʱ����
        while (!DL_GPIO_readPins(KEY3_PORT, KEY3_PIN)) {
            KeyNum =1 ;
        }
		 delay_ms(5);
    }

    if (!DL_GPIO_readPins(KEY1_PORT, KEY1_PIN)) {
        delay_ms(10);  // ��ʱ����
        while (!DL_GPIO_readPins(KEY1_PORT, KEY1_PIN)) {
            KeyNum =2;
        }
		 delay_ms(5);
    }
     if (!DL_GPIO_readPins(KEY2_PORT, KEY2_PIN)) {
        delay_ms(10);  // ��ʱ����
        while (!DL_GPIO_readPins(KEY2_PORT, KEY2_PIN)) {
            KeyNum =3;
        }
		 delay_ms(5);
    }
 }
