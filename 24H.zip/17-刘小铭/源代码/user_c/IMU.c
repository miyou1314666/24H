//#include "IMU.h"


//int16_t Ax,Ay,Az,Gx,Gy,Gz;
//param_imu imu_data;
//float q[4]={1.0,0.0,0.0};


//float fast_sqrt(float x)
//{
//	float halfx= 0.5f *x;
//	float y=x;
//	long i = * (long*)&y;
//	i = 0x5f3759df -(i>>1);
//	y = *(float*)&i;
//	y = y*(1.5f-(halfx * y * y));
//	return y;
//}



//void IMU_GetValues(void)
//{
//	MPU6050_GetData(&Ax,&Ay,&Az,&Gx,&Gy,&Gz);
//	imu_data.AX=((float)Ax)/2048;
//	imu_data.AY=((float)Ay)/2048;
//	imu_data.AZ=((float)Az)/2048;
//	imu_data.GX=((float)Gx)*0.001064;
//	imu_data.GY=((float)Gy)*0.001064;
//	imu_data.GZ=((float)Gz)*0.001064;
//}


//void IMU_AHRSupdate(param_imu* imu_temp)
//{
//	float ax,ay,az;
//	float gx,gy,gz;
//	ax=imu_temp->AX;
//	ay=imu_temp->AY;
//	az=imu_temp->AZ;
//	gx=imu_temp->GX;
//	gy=imu_temp->GY;
//	gz=imu_temp->GZ;
//	
//	float vx,vy,vz;

//	float q0=q[0];
//	float q1=q[1];
//	float q2=q[2];
//	float q3=q[3];
//	
//	float norm=fast_sqrt(ax*ax+ay*ay+az*az);
//	
//	ax =ax*norm;
//    ay =ay*norm;
//	az =az*norm;
//	
//	vx = 2*(q1*q3-q0*q2);
//	vy = 2*(q1*q3-q0*q2);
//	vz = q0*q0-q1*q1-q2*q2+q3*q3;
//	
//	
//}


