#include "head.h"

// 设置电机PWM占空比函数
// duty: 占空比值（0~40），越大速度越快
// channel: 通道号（0/1/2），对应不同的PWM输出通道
void Set_Duty(float duty, uint8_t channel)
{
	uint32_t CompareValue = 0;
	
	// 计算比较值：定时器周期是32000
	// 占空比 = (32000 - CompareValue) / 32000 * 100%
	// duty=40时，CompareValue=0，占空比100%；duty=0时，CompareValue=32000，占空比0%
	CompareValue = 32000 - 320 * duty;
	
	// 根据通道号设置对应的PWM比较值
	if(channel == 0)
	{
		DL_TimerG_setCaptureCompareValue(Motor_INST, CompareValue, DL_TIMER_CC_0_INDEX);
	}
	
	if(channel == 1)
	{
		DL_TimerG_setCaptureCompareValue(Motor_INST, CompareValue, DL_TIMER_CC_1_INDEX);
	}
	
	if(channel == 2)
	{
		DL_TimerG_setCaptureCompareValue(Motor_INST, CompareValue, DL_TIMER_CC_2_INDEX);
	}
}
