#include "head.h"

// 模式控制变量
int basespeed;         // 基础速度
int mode1_start;       // 模式1启动标志
int mode1_times;       // 模式1定时器
int mode2_start;       // 模式2启动标志
int mode2_times;       // 模式2定时器
int cycle_times;       // 循环次数
int mode0_start;       // 模式0启动标志

int flag_mode1=0;      // 模式状态标志1
int flag_mode2=0;      // 模式状态标志2
int mode1_angle=0;     // 角度补偿值

// ========== 模式0：A点到B点直走（任务1）==========
void mode0(void)	
{
    HUIDU();  // 读取灰度传感器
	
	// 阶段0：直走，使用陀螺仪保持方向
	if(flag_mode1 == 0)
	{
		Target_Yaw = 0;                // 目标角度为0度
		basespeed = 20;                // 基础速度20
		Left_Speed = basespeed - Yaw_OUT;   // 左速度 = 基础速度 - 角度偏差
		Right_Speed = basespeed + Yaw_OUT;  // 右速度 = 基础速度 + 角度偏差
	}
	
	// 启动时的声光提示
	if(flag_mode2 == 0)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);  // 开灯
		mode1_times++;
		if(mode1_times > 50)  // 延时一段时间
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);  // 关灯
			mode1_times = 0;
			flag_mode2 = 1;
		}
	}
	
	// 检测到黑线结束（到达B点）
	if(flag_mode1 == 0 && white() == 0)
	{
		flag_mode1 = 1;
		flag_mode2 = 2;
	}
	
	// 停止电机
	if(flag_mode1 == 1)
	{
		flag_mode1 = 2;
		Left_Speed = 0;
		Right_Speed = 0;
	}
	
	// 到达终点的声光提示
	if(flag_mode2 == 2)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);  // 开灯
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);  // 关灯
			mode1_times = 0;
			flag_mode2 = 3;
		}
	}
}	

// ========== 模式1：A-B-C-D-A 一圈（任务2）==========
void mode1(void)
{
	HUIDU();       // 读取灰度传感器
	HUIDUdouble(); // 双线循迹计算
	
	// 阶段0：A到B直走
	if(flag_mode1 == 0)
	{
		Target_Yaw = 0;
		basespeed = 20;
		Left_Speed = basespeed - Yaw_OUT;
		Right_Speed = basespeed + Yaw_OUT;
	}
	
	// 启动提示
	if(flag_mode2 == 0)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode2 = 1;
		}
	}
	
	// 到达B点（检测到黑线）
	if(flag_mode1 == 0 && white() == 0)
	{
		flag_mode1 = 1;
		flag_mode2 = 2;
	}
	
	// B点提示
	if(flag_mode2 == 2)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode2 = 3;
		}
	}
	
	// 阶段1：B到C弧线循迹（右半圆）
	if(flag_mode1 == 1)
	{
		basespeed = 18;
		Right_Speed = basespeed - correction;
		Left_Speed = basespeed + correction;
	}
	
	// 弧线走完（角度超过-170度）
	if(flag_mode1 == 1 && Rec_Yaw < -170)
	{
		flag_mode1 = 2;
		flag_mode2 = 3;
	}
	
	// C点提示
	if(flag_mode2 == 3)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode2 = 4;
		}
	}
	
	// 阶段2：C到D直走
	if(flag_mode1 == 2)
	{
		mode2_times++;
		Target_Yaw = 177 + mode1_angle;  // 目标角度加补偿
		basespeed = 20;
		Left_Speed = basespeed - Yaw_OUT;
		Right_Speed = basespeed + Yaw_OUT;
	}
	
	// 到达D点
	if(flag_mode1 == 2 && white() == 0 && mode2_times > 100)
	{
		mode2_times = 0;
		flag_mode1 = 3;
		flag_mode2 = 4;
	}
	
	// D点提示
	if(flag_mode2 == 4)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode2 = 5;
		}
	}
	
	// 阶段3：D到A弧线循迹（左半圆）
	if(flag_mode1 == 3)
	{
		basespeed = 18;
		Right_Speed = basespeed - correction;
		Left_Speed = basespeed + correction;
	}
	
	// 弧线走完，回到起点
	if(flag_mode1 == 3 && Rec_Yaw < -355)
	{
		Right_Speed = 0;
		Left_Speed = 0;
		flag_mode1 = 4;
		flag_mode2 = 6;
	}
	
	// 完成提示
	if(flag_mode2 == 6)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode2 = 7;
		}
	}
}

// ========== 模式2：A-C-B-D-A 循环（任务3/4）==========
void mode2(void)
{
	HUIDU();  // 读取灰度传感器
	
	// 启动检查：判断是否完成指定圈数
	if(flag_mode1 == 0)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode1 = 1;
			
			// 如果已经完成指定圈数，停止
			if(cycle_times >= mode4_times)
			{
				Left_Speed = 0;
				Right_Speed = 0;
				flag_mode2 = 10;
			}
		}
	}
	
	// 阶段0：A到C直走
	if(flag_mode2 == 0)
	{
		Target_Yaw = 323;                    // 目标角度323度
		Left_Speed = basespeed - Yaw_OUT * 0.4;   // 角度权重减小，更平滑
		Right_Speed = basespeed + Yaw_OUT * 0.4;
	}
	
	// 到达C点判断
	if(flag_mode2 == 0 && Rec_Yaw < -20)
	{
		mode2_times++;
		if(mode2_times > 200 && white() == 0)  // 延时+检测黑线
		{
			flag_mode2 = 1;
			flag_mode1 = 2;
			mode2_times = 0;
		}
	}
	
	// C点提示
	if(flag_mode1 == 2)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode1 = 3;
		}
	}
	
	// 阶段1：C到B弧线循迹（左弧线）
	if(flag_mode2 == 1)
	{
		HUIDUleft();  // 左弧线循迹算法
		Right_Speed = basespeed - correction;
		Left_Speed = basespeed + correction;
	}
	
	// 弧线走完判断
	if(flag_mode2 == 1 && Rec_Yaw > 168 && white() == 1)
	{
		flag_mode2 = 2;
		flag_mode1 = 4;
	}
	
	// B点提示
	if(flag_mode1 == 4)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode1 = 5;
		}
	}
	
	// 阶段2：B到D直走
	if(flag_mode2 == 2)
	{
		Target_Yaw = 215 - cycle_times + mode1_angle;  // 目标角度随圈数调整
		Left_Speed = basespeed - Yaw_OUT * 0.4;
		Right_Speed = basespeed + Yaw_OUT * 0.4;
	}
	
	// 到达D点判断
	if(flag_mode2 == 2 && Actual_Yaw > 205)
	{
		mode2_times++;
		if(mode2_times > 200 && white() == 0)
		{
			flag_mode2 = 3;
			flag_mode1 = 6;
			mode2_times = 0;
		}
	}
	
	// D点提示
	if(flag_mode1 == 6)
	{
		DL_GPIO_setPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
		mode1_times++;
		if(mode1_times > 50)
		{
			DL_GPIO_clearPins(GPIO_PORT_shotlight_PORT, GPIO_PORT_shotlight_PIN);
			mode1_times = 0;
			flag_mode1 = 7;
		}
	}
	
	// 阶段3：D到A弧线循迹（右弧线）
	if(flag_mode2 == 3)
	{
		HUIDUright();  // 右弧线循迹算法
		Right_Speed = basespeed - correction;
		Left_Speed = basespeed + correction;
	}
	
	// 回到A点，完成一圈
	if(flag_mode2 == 3 && Actual_Yaw < 10)
	{
		flag_mode2 = 0;    // 重置阶段标志
		flag_mode1 = 0;    // 重置状态标志
		cycle_times++;     // 圈数加1
	}
}
