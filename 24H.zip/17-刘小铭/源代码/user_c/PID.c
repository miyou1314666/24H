#include "head.h"

// 灰度循迹PID控制变量
volatile float error1;       // 当前误差（偏离黑线的程度）
volatile float lastError;    // 上一次误差
volatile float derivative1;  // 误差变化率（微分项）
volatile float correction;   // PID校正值

volatile int Left_Speed;     // 左电机速度
volatile int Right_Speed;    // 右电机速度
volatile int Target_HUIDU=0; // 目标灰度值

int HUIDU_test=0,HUIDU_test1=0,HUIDU_test2,HUIDU_test3,HUIDU_test4,mode4_times;

// 双线循迹（直线路径）
void HUIDUdouble()
{          	
	// 根据传感器检测结果计算误差
	// 传感器排列: [1][2][3][4][5][6] (中间是3和4)
	// 数值越大表示偏离越远，负数=偏左，正数=偏右
	
	if(sensorPins[1] == 0) error1 = -4;      // 最左边传感器检测到黑线
	else if(sensorPins[2] == 0) error1 = -4; // 左二传感器检测到黑线
	else if(sensorPins[3] == 0) error1 = -3; // 左三传感器检测到黑线
	else if(sensorPins[4] == 0) error1 =  3; // 右三传感器检测到黑线
	else if(sensorPins[5] == 0) error1 =  4; // 右二传感器检测到黑线
	else if(sensorPins[6] == 0) error1 =  5; // 最右边传感器检测到黑线
	else if(sensorPins[3] == 0 && sensorPins[4] == 0) error1 = 0;  // 正中
	
	// PD控制计算（比例+微分）
	derivative1 = error1 - lastError;        // 计算误差变化率
	correction = 1.6 * error1 + 0.5 * derivative1;  // PID公式：1.6是比例系数，0.5是微分系数
	lastError = error1;                       // 保存当前误差为下一次使用
}

// 左弧线循迹（走左边的半圆）
void HUIDUleft()
{          
	// 左弧线时，传感器权重调整，让小车更靠近弧线内侧
	
	if(sensorPins[1] == 0) error1 = -5;      // 最左边检测到黑线，误差更大
	else if(sensorPins[2] == 0) error1 = -4;
	else if(sensorPins[3] == 0) error1 = -3;
	else if(sensorPins[4] == 0) error1 =  3;
	else if(sensorPins[5] == 0) error1 =  4;
	else if(sensorPins[6] == 0) error1 =  2;  // 最右边权重变小
	else if(sensorPins[3] == 0 && sensorPins[4] == 0) error1 = 0;
	
	// PD控制计算
	derivative1 = error1 - lastError;
	correction = 1.6 * error1 + 0.5 * derivative1;
	lastError = error1;
}

// 右弧线循迹（走右边的半圆）
void HUIDUright()
{          
	// 右弧线时，传感器权重调整，让小车更靠近弧线内侧
	
	if(sensorPins[1] == 0) error1 = -2;      // 最左边权重变小
	else if(sensorPins[2] == 0) error1 = -4;
	else if(sensorPins[3] == 0) error1 = -3;
	else if(sensorPins[4] == 0) error1 =  3;
	else if(sensorPins[5] == 0) error1 =  4;
	else if(sensorPins[6] == 0) error1 =  5;  // 最右边检测到黑线，误差更大
	else if(sensorPins[3] == 0 && sensorPins[4] == 0) error1 = 0;
	
	// PD控制计算
	derivative1 = error1 - lastError;
	correction = 1.6 * error1 + 0.5 * derivative1;
	lastError = error1;
}

// 电机速度输出函数（每5ms调用一次）
void Motor(void)
{
	// 速度限幅：防止速度超过最大值或低于0
	if(Left_Speed > 40)  Left_Speed = 40;
	if(Right_Speed > 40) Right_Speed = 40;
	if(Left_Speed < 0)   Left_Speed = 0;
	if(Right_Speed < 0)  Right_Speed = 0;	                      
	
	// 设置PWM占空比（+1是为了保证最小速度）
	Set_Duty(Left_Speed + 1, 1);    // 左电机
	Set_Duty(Right_Speed + 1, 2);   // 右电机
}






