#include "head.h"  

volatile int32_t gEncoderCount, gEncoderCount1,gEncodersum, gEncodersum1;

uint32_t gpio_interrup;
void GROUP1_IRQHandler(void)
{
	
}